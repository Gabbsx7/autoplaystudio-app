import ChatDrawer from './ChatDrawer'
const DirectChatDrawer = () => <ChatDrawer channel="direct-chat" /> // stub – channel id TBD
export default DirectChatDrawer
